# Scripts

These are my personal scripts for various tasks (which are talked about briefly at the top of every script).

You can take and use anything in this repo freely as it is licensed under the GPL v3. However, if you have any issues with using them, I do not provide any type of support as I tailor these scripts entirely for my set up. I have done my best to comment everything so it can easily be understood. I will accept pull requests if you feel something could be better!
