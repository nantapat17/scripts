# Ren'Py Ingame Console
A simulation of a console in Ren'Py for gameplay purposes.
